from django import forms
from .models import Achievement

class AchievementForm(forms.ModelForm):
  class Meta:
    model = Achievement
    fields = ['codenumber', 'name', 'managementnumber', 'product', 'quantity', 'starttime', 'endtime']
    widgets = {
      'starttime': forms.DateTimeInput(attrs={'type': 'datetime-local'}, format='%Y-%m-%dT%H:%M'),
      'endtime': forms.DateTimeInput(attrs={'type': 'datetime-local'}, format='%Y-%m-%dT%H:%M'),
    }

  def __init__(self, *args, **kwargs):
    super().__init__(*args, **kwargs)
    if self.instance and self.instance.starttime:
      self.initial['starttime'] = self.instance.starttime.strftime('%Y-%m-%dT%H:%M')
    if self.instance and self.instance.endtime:
      self.initial['endtime'] = self.instance.endtime.strftime('%Y-%m-%dT%H:%M')