from django.contrib import admin
from import_export import resources
from import_export.admin import ImportExportModelAdmin
from .models import CodeList,ProductList,Achievement
from .models import Record


class CodeListResource(resources.ModelResource):

    class Meta:
        fields = ['code','name']
        skip_duplicates = True
        import_id_fields = ('code',)
        model = CodeList

class CodeListAdmin(ImportExportModelAdmin):
    ordering = ['code']
    list_display = ('code','name')
    search_fields = ('name',)
    resource_class = CodeListResource

admin.site.register(CodeList,CodeListAdmin)


class ProductListResource(resources.ModelResource):

    class Meta:
        fields = ['product','customer','surfaceinspectiontime','backinspectiontime','endfaceinspectiontime','pointinspectiontime']
        skip_duplicates = True
        import_id_fields = ('product',)
        model = ProductList

class ProductListAdmin(ImportExportModelAdmin):
    ordering = ['product']
    list_display = ('product','customer','surfaceinspectiontime','backinspectiontime','endfaceinspectiontime','pointinspectiontime')
    search_fields = ('product',)
    resource_class = ProductListResource

admin.site.register(ProductList,ProductListAdmin)


class AchievementResource(resources.ModelResource):

    class Meta:
        fields = ["codenumber","name","managementnumber","product","quantity","starttime","endtime"]
        skip_duplicates = True
        import_id_fields = ("managementnumber",)
        model = Achievement

class AchievementAdmin(ImportExportModelAdmin):
    ordering = ["managementnumber"]
    list_display = ("codenumber","name","managementnumber","product","quantity","process","starttime","endtime")
    search_fields = ("managementnumber",)
    resource_class = AchievementResource

admin.site.register(Achievement,AchievementAdmin)
admin.site.site_header = '実績管理'
admin.site.index_title = '実績管理画面'

admin.site.register(Record)


