from django.db import models
from django.urls import reverse
from django.utils import timezone
from django.utils.timezone import make_aware, get_default_timezone
from datetime import timedelta, datetime
from django.db import models
import logging


class CodeList(models.Model):
    code = models.CharField('codeNO',max_length=9,unique=True)
    name = models.CharField('氏名',max_length=20)

    class Meta:
        verbose_name_plural = '作業者名一覧'

    def __str__(self):
        return self.name
    

class ProductList(models.Model):
    product = models.CharField('品名',max_length=12)
    customer = models.CharField('客先',max_length=30)
    surfaceinspectiontime = models.IntegerField('表面検査時間',null=True)
    backinspectiontime = models.IntegerField('背面検査時間',null=True)
    endfaceinspectiontime = models.IntegerField('端面検査時間',null=True)
    pointinspectiontime = models.IntegerField('ポイント検査時間',null=True)

    class Meta:
        verbose_name_plural = '品名一覧'

    def __str__(self):
        return self.product

logger = logging.getLogger(__name__)

class Achievement(models.Model):
    OPTION_CHOICES = [
        ('1','表面検査'),
        ('2','背面検査'),
        ('3','端面検査'),
        ('4','ポイント検査'),
        ]
    codenumber =models.CharField(verbose_name="作業者NO",max_length=9)
    name = models.CharField(verbose_name="作業者名",max_length=20,blank=True)
    managementnumber = models.CharField(verbose_name="管理NO",max_length=12,null=True)
    product = models.CharField(verbose_name="品名",max_length=12)
    quantity = models.IntegerField(verbose_name="数量",null=True)
    process = models.CharField(verbose_name="工程",choices=OPTION_CHOICES,max_length=6,blank=True) 
    starttime = models.DateTimeField(verbose_name="開始時間",null=True)
    endtime = models.DateTimeField(verbose_name="終了時間",blank=True,null=True)


    class Meta:
        verbose_name_plural = '実績一覧'
    
    def __str__(self):
        return self.name
    
    def save(self, *args, **kwargs):

        if self.starttime and timezone.is_naive(self.starttime):
    
            logger.debug('Original starttime (naive): %s', self.starttime)

            self.starttime = timezone.make_aware(self.starttime, timezone.get_default_timezone())

        try:
            code_entry = CodeList.objects.get(code=self.codenumber)
            self.name = code_entry.name
        except CodeList.DoesNotExist:
            self.name = ''
    
        try:
            logger.debug('Calculating endtime with starttime=%s', self.starttime)

            if self.starttime and self.quantity and self.process:
                code_entry = CodeList.objects.get(code=self.codenumber)
                self.name = code_entry.name
                product_entry = ProductList.objects.get(product=self.product)
                times = {
                    '1': product_entry.surfaceinspectiontime,
                    '2': product_entry.backinspectiontime,
                    '3': product_entry.endfaceinspectiontime,
                    '4': product_entry.pointinspectiontime
                }

            duration_minutes = times.get(self.process)

            if duration_minutes and self.starttime and self.quantity:
                additionalMinutes = (self.quantity / 100) * duration_minutes
                self.endtime = self.starttime + timedelta(minutes=additionalMinutes)

                logger.debug('Calculated endtime: %s', self.endtime)
    
        except Exception as e:
            logger.error('Error calculating endtime: %s', e)

        super().save(*args, **kwargs)


    