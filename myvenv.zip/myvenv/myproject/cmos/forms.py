from django.forms import ModelForm
from .models import InputList


class InputListForm(ModelForm):
    class Meta:
        model = InputList
        fields = ["code_list","product_name","prosess_name","quantity","start_time","end_time"]
        
        