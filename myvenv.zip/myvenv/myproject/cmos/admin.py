from django.contrib import admin
from .models import CodeList
from .models import InputList
from import_export import resources
from import_export.admin import ImportExportMixin
from import_export.formats import base_formats


class CodeListResource(resources.ModelResource):
    class Meta:
        model = CodeList
        skip_duplicates = True
        import_id_fields = ('code' ,)

class CodeListAdmin(ImportExportMixin, admin.ModelAdmin):
    ordering = ['code']
    list_display = ('code','name')
    search_fields = ('code',)
    resource_class = CodeListResource
    formats = [base_formats.XLSX]

admin.site.register(CodeList,CodeListAdmin)

class InputListResource(resources.ModelResource):
    class Meta:
        model = InputList
        skip_duplicates = True
        import_id_fields = ("code_list" ,)

class InputListAdmin(ImportExportMixin, admin.ModelAdmin):
    ordering = ["code_list"]
    list_display = ("code_list","product_name","prosess_name","quantity","start_time","end_time")
    search_fields = ("code_list",)
    resource_class = InputListResource
    autocomplete_fields = ("code_list", )

admin.site.register(InputList, InputListAdmin)

