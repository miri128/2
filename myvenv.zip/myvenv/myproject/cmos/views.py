from django.shortcuts import render
from django.views.generic import ListView,CreateView
from .models import CodeList
from .models import InputList
from .forms import InputListForm
from django.urls import reverse_lazy


class CodeListView(ListView):
    model = CodeList
    template_name = 'codelist.html'


class InputListView(ListView):
    model = InputList
    template_name = 'inputlist.html'


class IndexView(ListView):
    template_name = "achievements.html"
    context_object_name = "records"
    model = InputList


class InsertView(CreateView):
    form_class = InputListForm
    template_name = "inputform.html"
    success_url = reverse_lazy("insertapp:index")

    def form_valid(self,form):
        data = form.save(commit=False)
        
        data.save()

        return super().form_valid(form)



    