from django.db import models

class CodeList(models.Model):
    code = models.CharField(verbose_name="バーコードNO",max_length=9,primary_key=True)
    name = models.CharField(verbose_name="作業者名",max_length=20)

    def __str__(self):
        return self.name
    
    class Meta():
        verbose_name_plural = "作業者コード一覧"
        


class InputList(models.Model):
    OPTION_CHOICES = (
        ("A","表面検査"),
        ("B","背面検査"),
        ("C","端面検査"),
        ("D","ポイント検査")
    )

    #code = models.CharField(verbose_name="バーコードNO",max_length=9)
    #name= models.CharField(verbose_name="作業者名",max_length=20)
    code_list = models.ForeignKey(CodeList, verbose_name="CodeList", on_delete=models.CASCADE)
    product_name = models.CharField(verbose_name="品名",max_length=12)  
    prosess_name = models.CharField(verbose_name="工程名", max_length=10, choices=OPTION_CHOICES)
    quantity = models.IntegerField(verbose_name="数量")    
    start_time = models.DateTimeField(verbose_name="開始時間")    
    end_time = models.DateTimeField(verbose_name="終了時間")

    def __str__(self):
        return self.code_list

    class Meta():
        verbose_name_plural = "実績一覧"
