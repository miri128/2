from django.urls import reverse_lazy
from django.views.generic import TemplateView,ListView
from django.views.generic.edit import CreateView,UpdateView,DeleteView
from .models import Achievement
from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from .models import CodeList,ProductList
from django.http import HttpResponseRedirect


class TopView(TemplateView):
    template_name = "top.html"

class AchievementListView(ListView):
    model = Achievement
    template_name = "Achievement.html"
    paginate_by = 5

class AchievementCreateView(CreateView):
    model = Achievement
    fields = "__all__"
    success_url = reverse_lazy('list')
    template_name = "Create_forms.html"

    def post(self, request, *args, **kwargs):
        print("POST received:", request.POST)  # POSTデータの確認
        return super().post(request, *args, **kwargs)

    def form_valid(self, form):
        print("Form is valid")
        achievement = form.save(commit=False)
        
        print("POST data:", self.request.POST)  # POSTデータの詳細を確認
        
        achievement.codenumber = self.request.POST.get('codenumber')
        achievement.name = self.request.POST.get('name')
        achievement.managementnumber = self.request.POST.get('managementnumber')
        achievement.product = self.request.POST.get('product')
        achievement.quantity = self.request.POST.get('quantity')
        achievement.process = self.request.POST.get('process')
        achievement.starttime = self.request.POST.get('starttime')
        achievement.endtime = self.request.POST.get('endtime')
        
        try:
            achievement.save()
            print("Save successful")
            return HttpResponseRedirect(self.success_url)
        except Exception as e:
            print("Save failed:", str(e))
            return self.form_invalid(form)

    def form_invalid(self, form):
        print("Form is invalid")
        print("Form errors:", form.errors)
        return super().form_invalid(form)
    

class AchievementUpdateView(UpdateView):
    model = Achievement
    fields = "__all__"
    template_name = "update_forms.html"

    def form_valid(self, form):
        self.object = form.save()
        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy('list')
    
class AchievementDeleteView(DeleteView):
    model = Achievement
    success_url = reverse_lazy('list')
    template_name = "delete_forms.html"

    def delete_view(request, pk):
        obj = get_object_or_404(Achievement, pk=pk)
        context = {'object':obj}

        if request.method == "POST":
            obj.delete()
            return render('list')
    
        return render(request, 'delete_forms.html', context)
    
def get_name_from_code(reqest):
    code = reqest.GET.get('code', None)
    print(code)
    if code:
        try:
            code_list_entry = CodeList.objects.get(code=code)
            name = code_list_entry.name
        except CodeList.DoesNotExist:
            name = 'Not found'

    return JsonResponse({'name': name})

def get_product_times(request):
    product = request.GET.get('product', '')
    print(product)

    try:
        product_entry = ProductList.objects.get(product=product)
        print(product_entry)
        return JsonResponse({
            'time1': product_entry.surfaceinspectiontime or 0,
            'time2': product_entry.backinspectiontime or 0,
            'time3': product_entry.endfaceinspectiontime or 0,
            'time4': product_entry.pointinspectiontime or 0,
        })
    except ProductList.DoesNotExist:
        print("見つからない")
        return JsonResponse({
            'time1': 0,
            'time2': 0,
            'time3': 0,
            'time4': 0,
        })
"""
def get_product_times(request):
    product = request.GET.get('product', '')
    print(product)    
"""    
