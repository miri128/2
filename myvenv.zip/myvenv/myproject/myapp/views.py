from django.shortcuts import render,redirect
from django.views.generic import TemplateView
from .models import Achievement
from .forms import AchievementForm


class TopView(TemplateView):
    template_name = "forms.html"

def CreateAchievement(request):
    if request.method == "POST":
        form = AchievementForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("AchievementList")
    else:
        form = AchievementForm()
        
    return render(request,"forms.html",{"form":form})


def AchievementList(request):
    Achievements = Achievement.objects.all()
    return render(request,"AchievementList.html",{"Achievements":Achievements})

