from django.db import models
from django.urls import reverse
from django.utils import timezone
from datetime import timedelta
from datetime import datetime


class CodeList(models.Model):
    code = models.CharField('codeNO',max_length=9,unique=True)
    name = models.CharField('氏名',max_length=20)

    class Meta:
        verbose_name_plural = '作業者名一覧'

    def __str__(self):
        return self.name
    

class ProductList(models.Model):
    product = models.CharField('品名',max_length=12)
    customer = models.CharField('客先',max_length=30)
    surfaceinspectiontime = models.IntegerField('表面検査時間',null=True)
    backinspectiontime = models.IntegerField('背面検査時間',null=True)
    endfaceinspectiontime = models.IntegerField('端面検査時間',null=True)
    pointinspectiontime = models.IntegerField('ポイント検査時間',null=True)

    class Meta:
        verbose_name_plural = '品名一覧'

    def __str__(self):
        return self.product


class Achievement(models.Model):
    OPTION_CHOICES = [
        ('1','表面検査'),
        ('2','背面検査'),
        ('3','端面検査'),
        ('4','ポイント検査'),
        ]
    codenumber =models.CharField(verbose_name="作業者NO",max_length=9)
    name = models.CharField(verbose_name="作業者名",max_length=20,blank=True)
    managementnumber = models.CharField(verbose_name="管理NO",max_length=12,null=True)
    product = models.CharField(verbose_name="品名",max_length=12)
    quantity = models.IntegerField(verbose_name="数量",null=True)
    process = models.CharField(verbose_name="工程",choices=OPTION_CHOICES,max_length=6,blank=True) 
    starttime = models.TimeField(verbose_name="開始時間",null=True)
    endtime = models.TimeField(verbose_name="終了時間",blank=True)


    class Meta:
        verbose_name_plural = '実績一覧'
    
    def __str__(self):
        return self.name
    
    def save(self, *args, **kwargs):
        try:
            code_entry = CodeList.objects.get(code=self.codenumber)
            self.name = code_entry.name
        except CodeList.DoesNotExist:
            self.name = ''
    
        try:
            product_entry = ProductList.objects.get(product=self.product)
            times = {
                '1': product_entry.surfaceinspectiontime,
                '2': product_entry.backinspectiontime,
                '3': product_entry.endfaceinspectiontime,
                '4': product_entry.pointinspectiontime
            }

            duration_minutes = times.get(self.process)

            if duration_minutes and self.starttime:
                start_datetime = timezone.make_aware(datetime.combine(timezone.now().date(), self.starttime))
                end_datetime = start_datetime + timedelta(minutes=duration_minutes)
                self.endtime = end_datetime.time()

        except ProductList.DoesNotExist:
            pass

        super().save(*args, **kwargs)

    